#ifndef __ARCH_I386_PERCPU__
#define __ARCH_I386_PERCPU__

#include <asm-generic/percpu.h>

#endif /* __ARCH_I386_PERCPU__ */
