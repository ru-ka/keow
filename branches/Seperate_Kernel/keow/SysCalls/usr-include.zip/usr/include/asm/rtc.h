#ifndef _I386_RTC_H
#define _I386_RTC_H

/*
 * x86 uses the default access methods for the RTC.
 */

#include <asm-generic/rtc.h>

#endif
