#ifndef _I386_SIGINFO_H
#define _I386_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif
