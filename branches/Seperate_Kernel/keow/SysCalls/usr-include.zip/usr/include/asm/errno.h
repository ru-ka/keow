#ifndef _I386_ERRNO_H
#define _I386_ERRNO_H

#include <asm-generic/errno.h>

#endif
