/* Hook to call BIOS initialisation function */

/* no action for generic */

#define ARCH_SETUP
