#ifndef _I386_SECTIONS_H
#define _I386_SECTIONS_H

/* nothing to see, move along */
#include <asm-generic/sections.h>

#endif
