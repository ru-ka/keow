#ifndef _I386_STATFS_H
#define _I386_STATFS_H

#include <asm-generic/statfs.h>

#endif
